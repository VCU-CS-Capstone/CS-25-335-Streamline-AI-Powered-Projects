// Import required modules
const express = require('express');
const path = require('path');
require('dotenv').config();

const OpenAI = require('openai');

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

let conversationHistory = [
  {
    role: 'system',
    content: `You are a friendly and insightful travel assistant named TravelBot. Your goal is to help users discover their ideal travel destinations by asking leading questions about their preferences and interests. Provide personalized suggestions based on their answers and engage them in a conversational manner. This will be done by collecting details about their experience like what they are celebrating, what they are looking to do, what region they want to be in, and what kind of experience they are looking for to perfect your recommendations.`,
  },
];

app.post('/api/openai', async (req, res) => {
  const { prompt } = req.body;

  // Add the user's message to the conversation history
  conversationHistory.push({ role: 'user', content: prompt });

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: conversationHistory,
      temperature: 0.7,
    });

    const assistantMessage = response.choices[0].message;

    // Add the assistant's response to the conversation history
    conversationHistory.push(assistantMessage);

    // Return the assistant's message to the client
    res.json(assistantMessage);
  } catch (error) {
    console.error('Error calling OpenAI API:', error);
    res.status(500).json({ error: 'Error communicating with OpenAI API' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
