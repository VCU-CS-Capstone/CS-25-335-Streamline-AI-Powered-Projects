$(function() {
    // Make the list items draggable
    $("#activities-list li").draggable({
      helper: "clone"
    });
  
    // Make the itinerary list droppable
    $("#itinerary-list").droppable({
      accept: "#activities-list li",
      drop: function(event, ui) {
        var item = $(ui.draggable).clone();
        $(this).append(item);
      }
    });
    // Fade-out effect on scroll for the hero section
window.addEventListener('scroll', function() {
    const hero = document.getElementById('hero');
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const heroHeight = hero.offsetHeight;
  
    // Calculate the opacity based on scroll position
    if (scrollTop < heroHeight) {
      hero.style.opacity = 1 - scrollTop / heroHeight;
    } else {
      hero.style.opacity = 0;
    }
  });
  
  
    // Calculate Estimated Budget
    $("#calculate-budget").click(function() {
      var activityCount = $("#itinerary-list li").length;
      var estimatedBudget = activityCount * 100; // Example calculation
      $("#estimated-budget").text("Estimated Budget: $" + estimatedBudget);
    });
  
    // Packing List Generator
    $("#packing-list-form").submit(function(event) {
      event.preventDefault();
      var destination = $("#destination").val();
      var lengthOfStay = $("#length-of-stay").val();
      var packingItems = [
        "Passport",
        "Travel Insurance",
        "Clothing x" + lengthOfStay,
        "Toiletries",
        "Camera"
      ];
      $("#packing-list").empty();
      packingItems.forEach(function(item) {
        $("#packing-list").append("<li>" + item + "</li>");
      });
    });
  });